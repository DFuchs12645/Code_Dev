var boxcolor = document.getElementById('boxcolor')
function branco(){
    boxcolor.style.background = 'white'
    boxcolor.style.color= 'black'

}
function verm(){
    boxcolor.style.background = 'red'
    boxcolor.style.color= 'white'
}
function verd(){
    boxcolor.style.background = 'green'
    boxcolor.style.color= 'white'
}
function az(){
    boxcolor.style.background = 'blue'
    boxcolor.style.color= 'white'
}

